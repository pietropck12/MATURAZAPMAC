<?php
declare(strict_types=1);

final class Service {
    public function __construct(public Store $db, public array $config) {}
    public static function defaults(): array { return [
        'product_id'=>7496, 'webhook_secret'=>'', 'uaz_url'=>'https://autorobosnet.uazapi.com', 'uaz_token'=>'',
        'message'=>"🎉 *Compra confirmada!*\n\nOlá, *{nome}*! 👋\nSeja bem-vindo ao *Matura Zap*! 💚\n\n📦 *Seu plano:* {plano}\n📅 *Válido até:* {expiracao}\n🧾 *Pedido:* #{pedido}\n\n🔑 *Ative sua licença*\nAcesse o link abaixo para obter sua chave:\n{link_ativacao}\n\n📧 *E-mail cadastrado:* {email}\nUse esse e-mail e a chave para entrar no aplicativo.\n\n🪟 *Baixar versão Windows:*\n{link_download_windows}\n\n🍎 *Baixar versão Mac:*\n{link_download_mac}\n\n🔄 Para consultar sua licença ou liberar um computador, use seu e-mail cadastrado em:\nhttps://maturazap.superzapmarketing.net/ativar\n\n🚀 Tudo pronto para começar!",
        'download_url'=>'https://maturazap.superzapmarketing.net/download/windows',
        'download_url_windows'=>'https://maturazap.superzapmarketing.net/download/windows',
        'download_url_mac'=>'https://maturazap.superzapmarketing.net/download/mac',
        'refund_policy'=>'suspend', 'cancel_policy'=>'suspend',
        'smtp_host'=>'', 'smtp_port'=>587, 'smtp_user'=>'', 'smtp_password'=>'', 'smtp_from'=>'', 'smtp_mode'=>'tls',
        'notification_channel'=>'whatsapp', 'github_repository'=>'', 'github_auto_sync'=>1, 'site_title'=>'Matura Zap',
    ]; }
    public function seal(string $text): string {
        $nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return base64_encode($nonce.sodium_crypto_secretbox($text,$nonce,base64_decode($this->config['app_key'],true)));
    }
    public function open(string $text): string {
        $raw=base64_decode($text,true);
        if ($raw===false || strlen($raw)<40) throw new RuntimeException('Dado protegido inválido.');
        $v=sodium_crypto_secretbox_open(substr($raw,24),substr($raw,0,24),base64_decode($this->config['app_key'],true));
        if($v===false) throw new RuntimeException('Não foi possível abrir o dado protegido.');
        return $v;
    }
    public function settings(): array {
        $v=self::defaults();$stored=[];
        foreach($this->db->all('SELECT name,value FROM settings') as $r){$stored[$r['name']]=true;$v[$r['name']]=json_decode($this->open($r['value']),true,512,JSON_THROW_ON_ERROR);}
        if(!isset($stored['download_url_windows'])){
            $legacy=(string)($v['download_url']??'');
            $v['download_url_windows']=rtrim($legacy,'/')===rtrim($this->config['base_url'],'/').'/download'?rtrim($this->config['base_url'],'/').'/download/windows':$legacy;
        }
        if(!str_contains((string)$v['message'],'{link_download_mac}')){
            $old="💻 *Baixe o Matura Zap para Windows:*\n{link_download}";
            $new="🪟 *Baixar versão Windows:*\n{link_download_windows}\n\n🍎 *Baixar versão Mac:*\n{link_download_mac}";
            $v['message']=str_replace($old,$new,(string)$v['message']);
        }
        return $v;
    }
    public function saveSettings(array $input,string $actor): void {
        $v=$this->settings();
        foreach(self::defaults() as $k=>$default) if(array_key_exists($k,$input)) {
            if(in_array($k,['uaz_token','webhook_secret','smtp_password'],true) && $input[$k]==='') continue;
            $v[$k]=is_int($default)?self::integer($input[$k],$k==='github_auto_sync'?0:1,$k==='github_auto_sync'?1:($k==='product_id'?2147483647:65535)):trim((string)$input[$k]);
        }
        if(array_key_exists('download_url_windows',$input))$v['download_url']=$v['download_url_windows'];
        self::httpsUrl($v['uaz_url']); self::httpsUrl($v['download_url_windows']); self::httpsUrl($v['download_url_mac']);
        if(!in_array($v['notification_channel'],['whatsapp','email','both'],true)) throw new Problem('Canal de mensagem inválido.');
        foreach(['refund_policy','cancel_policy'] as $k) if(!in_array($v[$k],['suspend','keep'],true)) throw new Problem('Política inválida.');
        if(!in_array($v['smtp_mode'],['tls','ssl'],true)) throw new Problem('Use TLS ou SSL no e-mail.');
        if($v['github_repository']!=='' && !preg_match('~^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$~',$v['github_repository'])) throw new Problem('Informe o GitHub no formato conta/repositorio.');
        if(strlen($v['webhook_secret'])<24) throw new Problem('O segredo do webhook precisa ter pelo menos 24 caracteres.');
        $this->db->tx(function()use($v,$actor){
            foreach($v as $k=>$value){
                $sealed=$this->seal(json_encode($value,JSON_THROW_ON_ERROR));
                if($this->db->one('SELECT name FROM settings WHERE name=?',[$k])) $this->db->run('UPDATE settings SET value=? WHERE name=?',[$sealed,$k]);
                else $this->db->insert('settings',['name'=>$k,'value'=>$sealed]);
            }
            $this->audit($actor,'integration.saved','settings','Configurações atualizadas; valores secretos omitidos.');
        });
    }
    public static function integer(mixed $v,int $min=0,int $max=100000): int {
        if(filter_var($v,FILTER_VALIDATE_INT)===false || (int)$v<$min || (int)$v>$max) throw new Problem("Informe um número inteiro entre $min e $max.");
        return (int)$v;
    }
    public static function email(string $v): string {
        $v=strtolower(trim($v));
        if(strlen($v)>190 || !filter_var($v,FILTER_VALIDATE_EMAIL)) throw new Problem('Informe um e-mail válido.');
        return $v;
    }
    public static function httpsUrl(string $v): void {
        if(!filter_var($v,FILTER_VALIDATE_URL) || strtolower((string)parse_url($v,PHP_URL_SCHEME))!=='https' || parse_url($v,PHP_URL_USER)!==null || parse_url($v,PHP_URL_PASS)!==null) throw new Problem('Informe uma URL HTTPS sem credenciais.');
    }
    public function audit(string $actor,string $action,string $target,string $detail=''): void {
        $this->db->insert('audit',['actor'=>substr($actor,0,190),'action'=>$action,'target'=>substr($target,0,190),'detail'=>$detail,'created_at'=>time()]);
    }
    public function rate(string $scope,string $subject,int $limit,int $seconds): void {
        $bucket=$scope.':'.hash('sha256',$subject).':'.intdiv(time(),$seconds);
        if($this->db->mysql) $this->db->run('INSERT INTO rate_limits (bucket,hits,expires_at) VALUES (?,1,?) ON DUPLICATE KEY UPDATE hits=hits+1',[$bucket,time()+$seconds]);
        else $this->db->run('INSERT INTO rate_limits (bucket,hits,expires_at) VALUES (?,1,?) ON CONFLICT(bucket) DO UPDATE SET hits=hits+1',[$bucket,time()+$seconds]);
        if((int)$this->db->value('SELECT hits FROM rate_limits WHERE bucket=?',[$bucket])>$limit) throw new Problem('Muitas tentativas. Aguarde alguns minutos.',429,'rate_limited');
    }
    public function savePlan(array $v,string $actor): int {
        $id=(int)($v['id']??0); $name=trim($v['name']??'');
        if($name==='' || mb_strlen($name)>190) throw new Problem('Informe o nome do plano.');
        $row=['name'=>$name,'duration_days'=>self::integer($v['duration_days']??30,1,36500),'max_pcs'=>self::integer($v['max_pcs']??1,0,10000),'max_whatsapp'=>self::integer($v['max_whatsapp']??1,0,10000),'quota_scope'=>$v['quota_scope']??'license','offline_hours'=>self::integer($v['offline_hours']??24,0,168),'reset_limit'=>!empty($v['reset_unlimited'])?-1:self::integer($v['reset_limit']??1,-1,10000),'reset_window_days'=>self::integer($v['reset_window_days']??30,0,365),'active'=>isset($v['active'])?1:0];
        if(!in_array($row['quota_scope'],['license','device'],true)) throw new Problem('Escopo inválido.');
        return $this->db->tx(function()use($row,$id,$v,$actor){
            if($id){ if(!$this->db->one('SELECT id FROM plans WHERE id=?',[$id])) throw new Problem('Plano não encontrado.',404); $this->update('plans',$id,$row); }
            else $id=$this->db->insert('plans',$row+['created_at'=>time()]);
            if(isset($v['map_enabled'])) {
                $product=(int)$this->settings()['product_id']; $variation=self::integer($v['variation_id']??0,0,2147483647);
                $existing=$this->db->one('SELECT * FROM product_maps WHERE product_id=? AND variation_id=?',[$product,$variation]);
                if($existing && (int)$existing['plan_id']!==$id) throw new Problem('Essa variação já está associada a outro plano.');
                if(!$existing) $this->db->insert('product_maps',['product_id'=>$product,'variation_id'=>$variation,'plan_id'=>$id]);
            }
            if(isset($v['remove_mapping'])) $this->db->run('DELETE FROM product_maps WHERE plan_id=?',[$id]);
            $this->audit($actor,'plan.saved',(string)$id,'Valores do plano salvos. Licenças existentes preservam seus limites individuais.');
            return $id;
        });
    }
    public function update(string $table,int $id,array $row): void {
        $this->db->run('UPDATE '.$table.' SET '.implode(',',array_map(fn($k)=>$k.'=?',array_keys($row))).' WHERE id=?',[...array_values($row),$id]);
    }
    public function saveUser(array $v,string $actor): int {
        $id=(int)($v['id']??0); $name=trim($v['name']??''); $email=self::email($v['email']??'');
        if($name===''||mb_strlen($name)>190) throw new Problem('Informe o nome do cliente.');
        $phone=preg_replace('/\D/','',$v['phone']??'');
        if($phone!=='' && !preg_match('/^[1-9][0-9]{7,14}$/',$phone)) throw new Problem('WhatsApp deve incluir o código do país e DDD.');
        $status=$v['status']??'active'; if(!in_array($status,['active','blocked'],true)) throw new Problem('Status inválido.');
        return $this->db->tx(function()use($v,$id,$name,$email,$phone,$status,$actor){
            $exists=$this->db->lock('SELECT * FROM users WHERE email=?',[$email]);
            if($exists && (int)$exists['id']!==$id) throw new Problem('Já existe um usuário com este e-mail.');
            if($id){ if(!$this->db->one('SELECT id FROM users WHERE id=?',[$id])) throw new Problem('Usuário não encontrado.',404); $this->update('users',$id,compact('name','email','phone','status')); }
            else $id=$this->db->insert('users',compact('name','email','phone','status')+['created_at'=>time()]);
            $this->audit($actor,'user.saved',(string)$id,'Cadastro atualizado.');
            if(!empty($v['create_license'])) $this->createLicense($id,(int)($v['plan_id']??0),$v,$actor);
            return $id;
        });
    }
    public function setUserLicensePcs(int $user,int $license,mixed $limit,string $actor,string $expires=''): void {
        $this->db->tx(function()use($user,$license,$limit,$actor,$expires){
            $l=$this->db->lock('SELECT * FROM licenses WHERE id=? AND user_id=?',[$license,$user]);
            if(!$l) throw new Problem('Licença não pertence a este usuário.',404);
            $max=self::integer($limit,0,10000);
            $changes=['max_pcs'=>$max,'revision'=>(int)$l['revision']+1];
            if($expires!=='')$changes['expires_at']=self::expiryDate($expires);
            $this->update('licenses',$license,$changes);
            $devices=$this->db->all('SELECT id FROM devices WHERE license_id=? AND active=1 ORDER BY first_seen,id',[$license]);
            if($max>0) foreach(array_slice($devices,$max) as $d) $this->revokeDevice((int)$d['id']);
            $this->audit($actor,'license.pcs.updated',(string)$license,'Limite de computadores atualizado pelo cadastro do usuário.');
        });
    }
    public static function expiryDate(string $date): int {
        $value=DateTimeImmutable::createFromFormat('!Y-m-d',$date,new DateTimeZone('America/Sao_Paulo'));
        if(!$value || $value->format('Y-m-d')!==$date)throw new Problem('Informe uma data de validade válida.');
        return $value->setTime(23,59,59)->getTimestamp();
    }
    public function portalByEmail(string $email): int {
        $email=self::email($email);
        $u=$this->db->one("SELECT id FROM users WHERE email=? AND status='active'",[$email]);
        if(!$u)throw new Problem('E-mail não autorizado. Use o e-mail da compra ou cadastrado pelo administrador.',403,'email_not_authorized');
        return (int)$u['id'];
    }
    public function deleteUser(int $id,string $actor): void {
        $this->db->tx(function()use($id,$actor){
            $u=$this->db->lock('SELECT * FROM users WHERE id=?',[$id]);if(!$u)throw new Problem('Usuário não encontrado.',404);
            $licenses=$this->db->all('SELECT id FROM licenses WHERE user_id=?',[$id]);
            foreach($licenses as $l){
                $this->db->lock('SELECT id FROM licenses WHERE id=?',[$l['id']]);
                foreach(['accounts','devices','resets'] as $table)$this->db->run('DELETE FROM '.$table.' WHERE license_id=?',[$l['id']]);
            }
            $this->db->run('DELETE FROM portal_tokens WHERE user_id=?',[$id]);
            // Keep only anonymous order identifiers so old Woo events cannot recreate access.
            $this->db->run("UPDATE orders SET user_id=0,license_id=NULL,status='deleted',applied=1 WHERE user_id=?",[$id]);
            $this->db->run('DELETE FROM licenses WHERE user_id=?',[$id]);
            foreach($this->db->all('SELECT id,recipient_cipher FROM outbox') as $message){
                $recipient=$this->open($message['recipient_cipher']);
                if($recipient===$u['email']||($u['phone']!==''&&$recipient===$u['phone']))$this->db->run('DELETE FROM outbox WHERE id=?',[$message['id']]);
            }
            foreach($this->db->all("SELECT id,payload_cipher FROM events WHERE kind='woocommerce' AND payload_cipher IS NOT NULL") as $event){
                $payload=json_decode($this->open($event['payload_cipher']),true);
                if(strtolower(trim($payload['billing']['email']??''))===$u['email'])$this->update('events',(int)$event['id'],['payload_cipher'=>null,'status'=>'ignored','detail'=>'Cadastro apagado pelo administrador.','processed_at'=>time()]);
            }
            $this->db->run('DELETE FROM users WHERE id=?',[$id]);
            $this->audit($actor,'user.deleted_permanently',(string)$id,'Cadastro, licenças, dispositivos e acessos removidos.');
        });
    }
    public function createLicense(int $user,int $plan,array $overrides,string $actor): int {
        $p=$this->db->one('SELECT * FROM plans WHERE id=?',[$plan]);
        if(!$p || !$p['active']) throw new Problem('Escolha um plano ativo.');
        $u=$this->db->one('SELECT * FROM users WHERE id=?',[$user]); if(!$u || $u['status']==='deleted') throw new Problem('Usuário não encontrado.',404);
        $key='MZ-'.strtoupper(implode('-',str_split(bin2hex(random_bytes(15)),5)));
        $row=['user_id'=>$user,'plan_id'=>$plan,'code_hash'=>hash('sha256',$key),'code_cipher'=>$this->seal($key),'status'=>'active','expires_at'=>time()+86400*(int)$p['duration_days'],'created_at'=>time()];
        foreach(['max_pcs','max_whatsapp','quota_scope','offline_hours','reset_limit','reset_window_days'] as $k) $row[$k]=$p[$k];
        foreach(['max_pcs','max_whatsapp'] as $k) if(isset($overrides[$k]) && $overrides[$k]!=='') $row[$k]=self::integer($overrides[$k],0,10000);
        foreach(['offline_hours','reset_limit','reset_window_days'] as $k) if(isset($overrides[$k]) && $overrides[$k]!=='') $row[$k]=self::integer($overrides[$k],$k==='reset_limit'?-1:0,$k==='offline_hours'?168:10000);
        if(!empty($overrides['reset_unlimited'])) $row['reset_limit']=-1;
        if(isset($overrides['quota_scope'])) { if(!in_array($overrides['quota_scope'],['license','device'],true))throw new Problem('Escopo inválido.');$row['quota_scope']=$overrides['quota_scope']; }
        if(!empty($overrides['duration_days'])) $row['expires_at']=time()+86400*self::integer($overrides['duration_days'],1,36500);
        if(!empty($overrides['expires_at'])) $row['expires_at']=self::expiryDate((string)$overrides['expires_at']);
        $id=$this->db->insert('licenses',$row); $this->audit($actor,'license.created',(string)$id,'Plano '.$p['name']);
        return $id;
    }
    public function manageLicense(int $id,array $v,string $actor): void {
        $this->db->tx(function()use($id,$v,$actor){
            $l=$this->db->lock('SELECT * FROM licenses WHERE id=?',[$id]); if(!$l) throw new Problem('Licença não encontrada.',404);
            $action=$v['operation']??'save';
            if($action==='renew'){
                $days=self::integer($v['days']??30,1,36500);
                $this->update('licenses',$id,['expires_at'=>max(time(),(int)$l['expires_at'])+86400*$days,'revision'=>(int)$l['revision']+1]);
                $this->audit($actor,'license.renewed',(string)$id,"Validade acrescida em $days dias. Status preservado."); return;
            }
            if($action==='reset'){ $this->resetDeviceLocked($l,(int)($v['device_id']??0),$actor,false); return; }
            if($action==='delete'){ $this->update('licenses',$id,['status'=>'revoked','revision'=>(int)$l['revision']+1]); $this->audit($actor,'license.revoked',(string)$id,'Licença excluída de uso; histórico preservado.'); return; }
            if($action==='status'){
                $status=$v['status']??'';if(!in_array($status,['active','suspended'],true))throw new Problem('Status inválido.');
                $this->update('licenses',$id,['status'=>$status,'revision'=>(int)$l['revision']+1]);$this->audit($actor,'license.status',(string)$id,$status);return;
            }
            $p=$this->db->one('SELECT * FROM plans WHERE id=?',[(int)($v['plan_id']??$l['plan_id'])]); if(!$p) throw new Problem('Plano inválido.');
            $row=['plan_id'=>(int)$p['id'],'revision'=>(int)$l['revision']+1];
            foreach(['max_pcs','max_whatsapp','offline_hours','reset_limit','reset_window_days'] as $k) $row[$k]=self::integer($v[$k]??$l[$k],$k==='reset_limit'?-1:0,$k==='offline_hours'?168:10000);
            if(!empty($v['reset_unlimited'])) $row['reset_limit']=-1;
            $row['quota_scope']=$v['quota_scope']??$l['quota_scope']; $row['status']=$v['status']??$l['status'];
            if(!in_array($row['quota_scope'],['license','device'],true)||!in_array($row['status'],['active','suspended','revoked'],true)) throw new Problem('Configuração inválida.');
            $row['test_group']=isset($v['test_group'])?1:0; $row['notes']=mb_substr((string)($v['notes']??''),0,4000);
            if(!empty($v['expires_at'])) $row['expires_at']=self::expiryDate((string)$v['expires_at']);
            $this->update('licenses',$id,$row);
            // Deterministic enforcement: preserve the earliest devices/accounts when a cap is reduced.
            $devices=$this->db->all('SELECT id FROM devices WHERE license_id=? AND active=1 ORDER BY first_seen,id',[$id]);
            if($row['max_pcs']>0) foreach(array_slice($devices,$row['max_pcs']) as $d) $this->revokeDevice((int)$d['id']);
            $accounts=$this->db->all('SELECT * FROM accounts WHERE license_id=? ORDER BY created_at,id',[$id]); $seen=[];
            foreach($accounts as $a){ $scope=$row['quota_scope']==='device'?(string)$a['device_id']:'all'; $seen[$scope]??=[]; $hash=$a['account_hash'];
                if(!in_array($hash,$seen[$scope],true) && $row['max_whatsapp']>0 && count($seen[$scope]) >= $row['max_whatsapp']) $this->db->run('DELETE FROM accounts WHERE id=?',[$a['id']]);
                elseif(!in_array($hash,$seen[$scope],true)) $seen[$scope][]=$hash;
            }
            $this->audit($actor,'license.updated',(string)$id,'Limites, plano, validade e status atualizados.');
        });
    }
    private function validLicense(array $l): void {
        if($l['status']!=='active') throw new Problem('Licença suspensa ou revogada. Entre em contato com o suporte.',403,'license_blocked');
        if((int)$l['expires_at']<time()) throw new Problem('Sua licença venceu. Renove o plano para continuar.',403,'license_expired');
        $u=$this->db->one('SELECT status FROM users WHERE id=?',[$l['user_id']]);
        if(!$u||$u['status']!=='active') throw new Problem('Usuário bloqueado. Entre em contato com o suporte.',403,'user_blocked');
    }
    public function sign(array $claims): array {
        $payload=base64_encode(json_encode($claims,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
        $key=openssl_pkey_get_private(file_get_contents($this->config['signing_key']));
        if(!$key || !openssl_sign($payload,$signature,$key,OPENSSL_ALGO_SHA256)) throw new RuntimeException('Falha ao assinar resposta.');
        return ['payload'=>$payload,'signature'=>base64_encode($signature)];
    }
    private function entitlement(array $l,array $d): array {
        $accounts=$this->db->all('SELECT account_hash FROM accounts WHERE device_id=? ORDER BY account_hash',[$d['id']]);
        return $this->sign(['type'=>'license','license_id'=>(int)$l['id'],'device_id'=>(int)$d['id'],'fingerprint'=>$d['fingerprint'],'revision'=>(int)$l['revision'],'issued_at'=>time(),'expires_at'=>(int)$l['expires_at'],'offline_until'=>min((int)$l['expires_at'],time()+max(300,(int)$l['offline_hours']*3600)),'max_pcs'=>(int)$l['max_pcs'],'max_whatsapp'=>(int)$l['max_whatsapp'],'quota_scope'=>$l['quota_scope'],'accounts'=>array_column($accounts,'account_hash')]);
    }
    public function activate(array $v): array {
        $email=isset($v['email']) && trim((string)$v['email'])!=='' ? self::email($v['email']) : null; $code=strtoupper(trim($v['license_key']??'')); $fp=$v['fingerprint']??'';
        if(!preg_match('/^MZ-(?:[A-F0-9]{5}-){5}[A-F0-9]{5}$/',$code)) throw new Problem('Chave de licença inválida.',403,'activation_denied');
        if(!preg_match('/^[a-f0-9]{64}$/',$fp)) throw new Problem('Identificador do computador inválido.');
        return $this->db->tx(function()use($v,$email,$code,$fp){
            $l=$this->db->lock('SELECT * FROM licenses WHERE code_hash=?',[hash('sha256',$code)]);
            if(!$l) throw new Problem('Chave de licença inválida.',403,'activation_denied');
            $u=$this->db->one('SELECT * FROM users WHERE id=?',[$l['user_id']]);
            if(!$u||($email!==null && !hash_equals($u['email'],$email))) throw new Problem('Chave de licença ou cadastro inválido.',403,'activation_denied');
            $this->validLicense($l);
            $d=$this->db->one('SELECT * FROM devices WHERE license_id=? AND fingerprint=?',[$l['id'],$fp]);
            if(!$d || !$d['active']) {
                $count=(int)$this->db->value('SELECT COUNT(*) FROM devices WHERE license_id=? AND active=1',[$l['id']]);
                if((int)$l['max_pcs']>0 && $count>=(int)$l['max_pcs']) throw new Problem('Limite de computadores atingido. Restaure uma ativação no portal.',403,'device_limit');
            }
            $credential=bin2hex(random_bytes(32));
            $row=['name'=>mb_substr(trim($v['device_name']??'Meu computador'),0,190),'token_hash'=>hash('sha256',$credential),'active'=>1,'last_seen'=>time(),'client_version'=>substr($v['version']??'',0,40)];
            if($d){ $this->update('devices',(int)$d['id'],$row); $d=array_merge($d,$row); }
            else { $row+=['license_id'=>$l['id'],'fingerprint'=>$fp,'first_seen'=>time()]; $row['id']=$this->db->insert('devices',$row); $d=$row; }
            $this->audit('client:'.$u['id'],'device.activated',(string)$d['id'],'Computador vinculado.');
            return ['credential'=>$credential,'entitlement'=>$this->entitlement($l,$d)];
        });
    }
    public function withDevice(string $token,callable $fn): mixed {
        if(!preg_match('/^[a-f0-9]{64}$/',$token)) throw new Problem('Ativação necessária.',401,'activation_required');
        return $this->db->tx(function()use($token,$fn){
            $d=$this->db->one('SELECT * FROM devices WHERE token_hash=?',[hash('sha256',$token)]);
            if(!$d) throw new Problem('Ativação não reconhecida.',401,'activation_required');
            $l=$this->db->lock('SELECT * FROM licenses WHERE id=?',[$d['license_id']]);
            $d=$this->db->lock('SELECT * FROM devices WHERE id=?',[$d['id']]);
            if(!$l||!$d['active']||!hash_equals($d['token_hash'],hash('sha256',$token))) throw new Problem('Este computador foi desvinculado.',403,'device_revoked');
            $this->validLicense($l); return $fn($l,$d);
        });
    }
    public function heartbeat(string $token,array $v): array {
        return $this->withDevice($token,function($l,$d)use($v){
            if(!hash_equals($d['fingerprint'],(string)($v['fingerprint']??''))) throw new Problem('Computador não reconhecido.',403,'device_mismatch');
            $this->update('devices',(int)$d['id'],['last_seen'=>time(),'client_version'=>substr($v['version']??'',0,40)]);
            return $this->entitlement($l,$d);
        });
    }
    public function account(string $token,array $v,bool $release=false): array {
        $phone=preg_replace('/\D/','',(string)($v['account']??''));
        if(!preg_match('/^[1-9][0-9]{7,14}$/',$phone)) throw new Problem('Informe a conta WhatsApp com código do país e DDD.');
        $hash=hash('sha256',$phone);
        return $this->withDevice($token,function($l,$d)use($phone,$hash,$release){
            if($release){ $this->db->run('DELETE FROM accounts WHERE device_id=? AND account_hash=?',[$d['id'],$hash]); return $this->entitlement($l,$d); }
            $own=$this->db->one('SELECT id FROM accounts WHERE device_id=? AND account_hash=?',[$d['id'],$hash]);
            if(!$own){
                $where='license_id=?'; $args=[$l['id']]; if($l['quota_scope']==='device'){ $where.=' AND device_id=?'; $args[]=$d['id']; }
                $exists=$this->db->one('SELECT id FROM accounts WHERE '.$where.' AND account_hash=?',[...$args,$hash]);
                $count=(int)$this->db->value('SELECT COUNT(DISTINCT account_hash) FROM accounts WHERE '.$where,$args);
                if(!$exists && (int)$l['max_whatsapp']>0 && $count>=(int)$l['max_whatsapp']) throw new Problem('Limite de contas WhatsApp atingido. Remova uma conta ou altere seu plano.',403,'whatsapp_limit');
                $this->db->insert('accounts',['license_id'=>$l['id'],'device_id'=>$d['id'],'account_hash'=>$hash,'label'=>'••••'.substr($phone,-4),'created_at'=>time()]);
            }
            return $this->entitlement($l,$d);
        });
    }
    private function revokeDevice(int $id): void { $this->db->run('UPDATE devices SET active=0 WHERE id=?',[$id]); $this->db->run('DELETE FROM accounts WHERE device_id=?',[$id]); }
    private function resetDeviceLocked(array $l,int $id,string $actor,bool $self): void {
        if($self && (int)$l['reset_limit']>=0){
            $since=(int)$l['reset_window_days']===0?0:time()-86400*(int)$l['reset_window_days'];
            $count=(int)$this->db->value('SELECT COUNT(*) FROM resets WHERE license_id=? AND actor=? AND created_at>=?',[$l['id'],$actor,$since]);
            if((int)$l['reset_limit']===0||$count>=(int)$l['reset_limit']) throw new Problem('Limite de restaurações atingido. Entre em contato com o suporte.',403,'reset_limit');
        }
        $devices=$this->db->all('SELECT id FROM devices WHERE license_id=? AND active=1'.($id?' AND id=?':''),$id?[$l['id'],$id]:[$l['id']]);
        if(!$devices) throw new Problem('Nenhuma ativação encontrada.');
        foreach($devices as $d) $this->revokeDevice((int)$d['id']);
        $this->db->run('UPDATE licenses SET revision=revision+1 WHERE id=?',[$l['id']]);
        $this->db->insert('resets',['license_id'=>$l['id'],'device_id'=>$id?:null,'actor'=>$actor,'created_at'=>time()]);
        $this->audit($actor,'device.reset',(string)$l['id'],'Ativação liberada; validade preservada.');
    }
    public function selfReset(int $user,int $license,int $device): void {
        $this->db->tx(function()use($user,$license,$device){ $l=$this->db->lock('SELECT * FROM licenses WHERE id=? AND user_id=?',[$license,$user]); if(!$l) throw new Problem('Licença não encontrada.',404); $this->validLicense($l); if(!$device) throw new Problem('Selecione o computador.'); $this->resetDeviceLocked($l,$device,'client:'.$user,true); });
    }
    public function portalLink(int $user): string {
        $token=bin2hex(random_bytes(32));
        $this->db->insert('portal_tokens',['user_id'=>$user,'token_hash'=>hash('sha256',$token),'expires_at'=>time()+1800,'created_at'=>time()]);
        return rtrim($this->config['base_url'],'/').'/ativar?token='.$token;
    }
    public function redeem(string $token): int {
        if(!preg_match('/^[a-f0-9]{64}$/',$token)) throw new Problem('Link inválido ou expirado. Solicite outro.',403);
        return $this->db->tx(function()use($token){
            $t=$this->db->lock('SELECT * FROM portal_tokens WHERE token_hash=?',[hash('sha256',$token)]);
            if(!$t||$t['used_at']!==null||$t['expires_at']<time()) throw new Problem('Link inválido ou expirado. Solicite outro.',403);
            $u=$this->db->one('SELECT * FROM users WHERE id=?',[$t['user_id']]); if(!$u||$u['status']!=='active') throw new Problem('Acesso indisponível. Contate o suporte.',403);
            $this->db->run('UPDATE portal_tokens SET used_at=? WHERE id=?',[time(),$t['id']]);
            return (int)$t['user_id'];
        });
    }
    public function requestPortal(string $email): void {
        $email=self::email($email); $this->rate('portal-email',$email,3,900);
        $u=$this->db->one("SELECT * FROM users WHERE email=? AND status='active'",[$email]); if(!$u) return;
        $link=$this->portalLink((int)$u['id']); $this->queueContact($u,"Olá, {$u['name']}!\n\nAcesse seu Matura Zap pelo link abaixo. Ele expira em 30 minutos e só pode ser usado uma vez.\n$link",'portal:'.bin2hex(random_bytes(12)));
    }
    public function queueContact(array $u,string $message,string $unique): void {
        $settings=$this->settings(); $channel=$settings['notification_channel'];
        $emailReady=$settings['smtp_host']!=='' && $settings['smtp_from']!=='';
        if(($channel==='whatsapp'||$channel==='both')&&$u['phone']!=='') $this->queue('whatsapp',$u['phone'],$message,$unique.':wa');
        if($channel==='email'||$channel==='both'||$u['phone']==='') $this->queue('email',$u['email'],$message,$unique.':email');
        if(!$emailReady&&$u['phone']==='') $this->audit('system','delivery.configuration_needed',(string)$u['id'],'Configure SMTP ou o WhatsApp cadastrado para entregar o acesso.');
    }
    public function queue(string $channel,string $recipient,string $message,string $unique): void {
        if($this->db->one('SELECT id FROM outbox WHERE unique_key=?',[$unique])) return;
        $this->db->insert('outbox',['unique_key'=>$unique,'channel'=>$channel,'recipient_cipher'=>$this->seal($recipient),'message_cipher'=>$this->seal($message),'next_attempt'=>time(),'created_at'=>time()]);
    }
    public function webhook(string $body,string $signature,string $delivery='',bool $replay=false): array {
        $s=$this->settings();
        if(!$replay && ($s['webhook_secret']===''||!hash_equals(base64_encode(hash_hmac('sha256',$body,$s['webhook_secret'],true)),$signature))) throw new Problem('Assinatura inválida.',401,'invalid_signature');
        if(strlen($body)>1048576) throw new Problem('Pedido excede o tamanho permitido.',413);
        try { $p=json_decode($body,true,512,JSON_THROW_ON_ERROR); } catch(Throwable){ throw new Problem('JSON inválido.'); }
        if(!is_array($p)) throw new Problem('Pedido inválido.');
        $eventKey=hash('sha256',$body); $existing=$this->db->one('SELECT * FROM events WHERE event_key=?',[$eventKey]);
        if($existing&&in_array($existing['status'],['processed','ignored'],true)) return ['status'=>'duplicate'];
        if(!$existing){
            try { $eventId=$this->db->insert('events',['event_key'=>$eventKey,'kind'=>'woocommerce','status'=>'received','detail'=>'Pedido recebido.','payload_cipher'=>$this->seal($body),'created_at'=>time()]); }
            catch(PDOException $e){ if(in_array((string)$e->getCode(),['23000','23505'],true)) return ['status'=>'duplicate']; throw $e; }
        } else $eventId=(int)$existing['id'];
        try {
            $result=$this->db->tx(function()use($p,$s,$eventId){
                $event=$this->db->lock('SELECT * FROM events WHERE id=?',[$eventId]);
                if(in_array($event['status'],['processed','ignored'],true)) return 'duplicate';
                $lines=array_values(array_filter($p['line_items']??[],fn($l)=>(int)($l['product_id']??0)===(int)$s['product_id']));
                if(!$lines){ $this->update('events',$eventId,['status'=>'ignored','detail'=>'Pedido sem o produto Matura Zap.','processed_at'=>time()]); return 'ignored'; }
                $status=(string)($p['status']??'');
                if(!in_array($status,['processing','completed','refunded','cancelled','failed','pending','on-hold'],true)) throw new Problem('Status do pedido não reconhecido.');
                $paid=in_array($status,['processing','completed'],true); $orderId=self::integer($p['id']??0,1,2147483647);
                $lines=array_values(array_filter($lines,fn($line)=>!$this->db->one("SELECT id FROM orders WHERE woo_id=? AND line_id=? AND status='deleted'",[$orderId,(int)($line['id']??0)])));
                if(!$lines){$this->update('events',$eventId,['status'=>'ignored','payload_cipher'=>null,'detail'=>'Pedido de cadastro apagado; acesso não recriado.','processed_at'=>time()]);return 'ignored';}
                $modified=strtotime(($p['date_modified_gmt']??$p['date_created_gmt']??'').' UTC')?:0;
                $billing=$p['billing']??[]; $email=self::email($billing['email']??'');
                $u=$this->db->lock('SELECT * FROM users WHERE email=?',[$email]);
                if(!$u&&!$paid){ $this->update('events',$eventId,['status'=>'processed','detail'=>'Pedido sem pagamento; acesso não criado.','processed_at'=>time()]); return 'processed'; }
                if(!$u){
                    $phone=preg_replace('/\D/','',$billing['phone']??'');
                    if(($billing['country']??'')==='BR'&&in_array(strlen($phone),[10,11],true)) $phone='55'.$phone;
                    $name=trim(($billing['first_name']??'').' '.($billing['last_name']??''))?:$email;
                    $userId=$this->db->insert('users',['name'=>mb_substr($name,0,190),'email'=>$email,'phone'=>$phone,'created_at'=>time()]);
                    $u=$this->db->one('SELECT * FROM users WHERE id=?',[$userId]);
                }
                foreach($lines as $line){
                    $lineId=self::integer($line['id']??0,1,2147483647); $variation=(int)($line['variation_id']??0);
                    $old=$this->db->lock('SELECT * FROM orders WHERE woo_id=? AND line_id=?',[$orderId,$lineId]);
                    if($old && $modified>0 && (int)$old['modified_at']>$modified) continue;
                    if((int)($line['quantity']??1)!==1) throw new Problem('Quantidade maior que uma unidade: revisão manual necessária.',409,'needs_review');
                    $map=$this->db->one('SELECT * FROM product_maps WHERE product_id=? AND variation_id=?',[$s['product_id'],$variation]);
                    if(!$map) throw new Problem('Associe a variação '.$variation.' do produto '.$s['product_id'].' a um plano e reprocesse o evento.',409,'needs_mapping');
                    $plan=$this->db->one('SELECT * FROM plans WHERE id=?',[$map['plan_id']]); if(!$plan||!$plan['active']) throw new Problem('O plano associado está inativo.',409,'needs_mapping');
                    if(!$old){ $oid=$this->db->insert('orders',['woo_id'=>$orderId,'line_id'=>$lineId,'user_id'=>$u['id'],'plan_id'=>$plan['id'],'status'=>$status,'modified_at'=>$modified,'created_at'=>time()]); $old=$this->db->one('SELECT * FROM orders WHERE id=?',[$oid]); }
                    if($paid&&!$old['applied']){
                        // The user row is locked: simultaneous orders cannot grant duplicate renewals.
                        $l=$this->db->lock("SELECT * FROM licenses WHERE user_id=? AND plan_id=? AND status='active' ORDER BY id DESC LIMIT 1",[$u['id'],$plan['id']]);
                        if($l){ $licenseId=(int)$l['id']; $this->update('licenses',$licenseId,['expires_at'=>max(time(),(int)$l['expires_at'])+86400*(int)$plan['duration_days'],'revision'=>(int)$l['revision']+1]); }
                        else $licenseId=$this->createLicense((int)$u['id'],(int)$plan['id'],[],'woocommerce');
                        $this->update('orders',(int)$old['id'],['license_id'=>$licenseId,'applied'=>1,'renewal_days'=>(int)$plan['duration_days']]);
                        $l=$this->db->one('SELECT * FROM licenses WHERE id=?',[$licenseId]);
                        $vars=['{nome}'=>$u['name'],'{email}'=>$u['email'],'{plano}'=>$plan['name'],'{pedido}'=>(string)$orderId,'{link_ativacao}'=>rtrim($this->config['base_url'],'/').'/ativar','{chave}'=>$this->open($l['code_cipher']),'{expiracao}'=>gmdate('d/m/Y',(int)$l['expires_at']),'{link_download}'=>$s['download_url_windows'],'{link_download_windows}'=>$s['download_url_windows'],'{link_download_mac}'=>$s['download_url_mac']];
                        $this->queueContact($u,strtr($s['message'],$vars),'order:'.$orderId.':'.$lineId);
                    }
                    if(in_array($status,['refunded','cancelled'],true) && $old['license_id'] && $s[$status==='refunded'?'refund_policy':'cancel_policy']==='suspend'){
                        $this->db->run("UPDATE licenses SET status='suspended', revision=revision+1 WHERE id=?",[$old['license_id']]);
                        $this->audit('woocommerce','license.suspended',(string)$old['license_id'],'Pedido '.$orderId.' / '.$status);
                    }
                    $this->update('orders',(int)$old['id'],['status'=>$status,'modified_at'=>$modified]);
                }
                $this->update('events',$eventId,['status'=>'processed','detail'=>'Pedido '.$orderId.' processado: '.$status,'processed_at'=>time()]);
                return 'processed';
            }); return ['status'=>$result];
        } catch(Problem $e){ $this->update('events',$eventId,['status'=>$e->kind==='needs_mapping'?'needs_mapping':'needs_review','detail'=>$e->getMessage()]); return ['status'=>'needs_review']; }
    }
    public function releaseFor(string $token,string $version): ?array {
        return $this->withDevice($token,function($l,$d)use($version){
            $rows=$this->db->all('SELECT * FROM releases WHERE active=1'.($l['test_group']?'':" AND channel='stable'"));
            usort($rows,fn($a,$b)=>version_compare($b['version'],$a['version']));
            foreach($rows as $r) if(version_compare($r['version'],$version,'>')) return $this->sign(['type'=>'update','version'=>$r['version'],'url'=>$r['url'],'sha256'=>$r['sha256'],'size_bytes'=>(int)$r['size_bytes'],'notes'=>$r['notes'],'mandatory'=>(bool)$r['mandatory'],'issued_at'=>time(),'expires_at'=>time()+3600]);
            return null;
        });
    }
    public function saveRelease(array $v,string $actor): void {
        $version=trim($v['version']??''); $url=trim($v['url']??''); $sha=strtolower(trim($v['sha256']??''));
        if(!preg_match('/^\d+\.\d+\.\d+(?:\.\d+)?$/',$version)) throw new Problem('Versão deve ser numérica, por exemplo 4.0.0.');
        self::httpsUrl($url);
        $repository=$this->settings()['github_repository'];
        if($repository===''||!str_starts_with($url,'https://github.com/'.$repository.'/releases/download/')) throw new Problem('Use um arquivo de release do repositório configurado em Integrações.');
        if(!preg_match('/^[a-f0-9]{64}$/',$sha)) throw new Problem('SHA-256 inválido.');
        $channel=$v['channel']??'test'; if(!in_array($channel,['test','stable'],true)) throw new Problem('Canal inválido.');
        $row=['version'=>$version,'url'=>$url,'sha256'=>$sha,'signature'=>'','size_bytes'=>self::integer($v['size_bytes']??0,1,2147483647),'notes'=>mb_substr((string)($v['notes']??''),0,12000),'channel'=>$channel,'active'=>isset($v['active'])?1:0,'mandatory'=>isset($v['mandatory'])?1:0];
        $id=(int)($v['id']??0);
        if($id) $this->update('releases',$id,$row); else $id=$this->db->insert('releases',$row+['created_at'=>time()]);
        $this->audit($actor,'release.saved',(string)$id,'Versão '.$version.' / '.$channel);
    }
}
