<?php
declare(strict_types=1);

final class Web {
    private string $path;
    public function __construct(private Service $s) { $this->path=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/'; }
    private function json(mixed $data,int $status=200): never { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR); exit; }
    private function go(string $to): never { header('Location: '.$to,true,303); exit; }
    private function body(): array { $raw=file_get_contents('php://input',false,null,0,1048577); if(strlen($raw)>1048576) throw new Problem('Solicitação muito grande.',413); try{$v=json_decode($raw,true,64,JSON_THROW_ON_ERROR);}catch(Throwable){throw new Problem('JSON inválido.');} if(!is_array($v))throw new Problem('JSON inválido.'); return $v; }
    private function token(): string { $v=$_SERVER['HTTP_AUTHORIZATION']??''; return str_starts_with($v,'Bearer ')?substr($v,7):''; }
    private function session(): void {
        $secure=!($this->s->config['development']??false);
        session_name('maturazap_session');
        session_save_path($this->s->config['storage'].'/sessions');
        ini_set('session.use_strict_mode','1'); ini_set('session.use_only_cookies','1');
        session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
        session_start(); $_SESSION['csrf']??=bin2hex(random_bytes(32));
        if(isset($_SESSION['admin_id'])&&($_SESSION['admin_seen']??0)<time()-3600) unset($_SESSION['admin_id']);
        if(isset($_SESSION['admin_id'])) $_SESSION['admin_seen']=time();
        if(isset($_SESSION['portal_user'])&&($_SESSION['portal_until']??0)<time()) unset($_SESSION['portal_user']);
    }
    private function csrf(): void { if(!isset($_POST['csrf'])||!hash_equals($_SESSION['csrf'],(string)$_POST['csrf'])) throw new Problem('Sua sessão expirou. Atualize a página.',403); }
    private function admin(): array {
        $a=isset($_SESSION['admin_id'])?$this->s->db->one('SELECT id,email FROM admins WHERE id=?',[$_SESSION['admin_id']]):null;
        if(!$a) $this->go('/entrar'); return $a;
    }
    public function run(): void {
        header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: no-referrer'); header('X-Frame-Options: DENY');
        header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'");
        header('Cache-Control: no-store');
        try{
            if($this->path==='/health') $this->json(['status'=>$this->s->db->value('SELECT 1')?'ok':'unavailable','application'=>'maturazap']);
            if(str_starts_with($this->path,'/api/')) $this->api();
            $this->session();
            if(($_SERVER['REQUEST_METHOD']??'GET')==='POST') { $this->csrf(); $this->post(); }
            if($this->path==='/') $this->go(isset($_SESSION['admin_id'])?'/admin':'/entrar');
            require_once __DIR__.'/Views.php';
            $views=new Views($this->s);
            if($this->path==='/entrar'){ $views->login(); return; }
            if($this->path==='/ativar'){ $views->portal(); return; }
            if($this->path==='/download'||$this->path==='/download/windows'){
                $r=$this->s->db->all("SELECT version,url FROM releases WHERE active=1 AND channel='stable'");
                usort($r,fn($a,$b)=>version_compare($b['version'],$a['version']));
                if($this->path==='/download/windows'&&isset($r[0]) && version_compare($r[0]['version'],'4.1.2','>=') && preg_match('~^https://github\.com/pietropck12/maturazap/releases/download/v[0-9.]+(?:-preparacao)?/MaturaZap-[0-9.]+-Windows\.zip$~',$r[0]['url'])) {
                    $this->go(str_replace('-Windows.zip','-Setup.exe',$r[0]['url']));
                }
                $views->download($r[0]??null); return;
            }
            if($this->path==='/download/mac')$this->go('https://github.com/pietropck12/MATURAZAPMAC/releases/latest');
            if($this->path==='/admin'){ $views->admin($this->admin()); return; }
            throw new Problem('Página não encontrada.',404);
        }catch(Problem $e){
            if(str_starts_with($this->path,'/api/')) $this->json(['error'=>$e->kind,'message'=>$e->getMessage()],$e->status);
            http_response_code($e->status);
            if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'&&session_status()===PHP_SESSION_ACTIVE){ $_SESSION['flash']=['error',$e->getMessage()]; $this->go($this->path==='/acao'?'/admin?view='.rawurlencode($this->safeView($_POST['return_view']??'dashboard')):($this->path==='/entrar'?'/entrar':'/ativar')); }
            echo '<!doctype html><meta charset="utf-8"><title>Matura Zap</title><p>'.htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8').'</p><a href="/">Voltar</a>';
        }catch(Throwable $e){
            $ref=bin2hex(random_bytes(6)); error_log('MaturaZap '.$ref.' '.get_class($e).' '.$e->getMessage());
            if(str_starts_with($this->path,'/api/')) $this->json(['error'=>'server_error','message'=>'Não foi possível concluir agora. Referência: '.$ref],500);
            http_response_code(500); echo 'Não foi possível concluir agora. Referência: '.$ref;
        }
    }
    private function safeView(string $v): string { return in_array($v,['dashboard','users','plans','licenses','integrations','events','messages','updates','audit'],true)?$v:'dashboard'; }
    private function api(): never {
        if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST') throw new Problem('Use POST.',405);
        $ip=$_SERVER['REMOTE_ADDR']??'unknown'; // Do not trust user-controlled forwarded headers.
        $this->s->rate('api-ip',$ip,600,60);
        if($this->path==='/api/webhooks/woocommerce'){
            $raw=file_get_contents('php://input',false,null,0,1048577);
            // WooCommerce sends a form-encoded ping when the webhook is first enabled.
            if(str_starts_with($_SERVER['CONTENT_TYPE']??'','application/x-www-form-urlencoded')&&preg_match('/^webhook_id=\d+$/',$raw)) $this->json(['status'=>'ready']);
            $this->json($this->s->webhook($raw,$_SERVER['HTTP_X_WC_WEBHOOK_SIGNATURE']??'',$_SERVER['HTTP_X_WC_WEBHOOK_DELIVERY_ID']??''));
        }
        $v=$this->body();
        if($this->path==='/api/license/activate'){ $this->s->rate('activation-ip',$ip,20,900); if(trim((string)($v['email']??''))!=='') $this->s->rate('activation-email',strtolower(trim($v['email'])),10,900); else $this->s->rate('activation-key',strtoupper(trim((string)($v['license_key']??''))),10,900); $this->json($this->s->activate($v)); }
        if($this->path==='/api/license/heartbeat') $this->json($this->s->heartbeat($this->token(),$v));
        if($this->path==='/api/license/account/reserve') $this->json($this->s->account($this->token(),$v));
        if($this->path==='/api/license/account/release') $this->json($this->s->account($this->token(),$v,true));
        if($this->path==='/api/updates/check'){
            $version=$v['version']??'0.0.0'; if(!preg_match('/^\d+\.\d+\.\d+(?:\.\d+)?$/',$version))throw new Problem('Versão inválida.');
            $this->json(['update'=>$this->s->releaseFor($this->token(),$version)]);
        }
        throw new Problem('Rota não encontrada.',404);
    }
    private function post(): never {
        $db=$this->s->db; $v=$_POST; $op=$v['action']??'';
        if($this->path==='/entrar'){
            $email=strtolower(trim($v['email']??'')); $this->s->rate('login-ip',$_SERVER['REMOTE_ADDR']??'',15,900); $this->s->rate('login-email',$email,10,900);
            $a=$db->one('SELECT * FROM admins WHERE email=?',[$email]);
            $hash=$a['password_hash']??'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
            if(!password_verify($v['password']??'',$hash)||!$a) throw new Problem('E-mail ou senha inválidos.',403);
            session_regenerate_id(true); $_SESSION['admin_id']=$a['id']; $_SESSION['admin_seen']=time(); $_SESSION['csrf']=bin2hex(random_bytes(32));
            $this->s->audit($a['email'],'admin.login',(string)$a['id']); $this->go('/admin');
        }
        if($this->path==='/ativar'){
            if($op==='request'){
                unset($_SESSION['portal_user'],$_SESSION['portal_until']);
                $this->s->rate('portal-ip',$_SERVER['REMOTE_ADDR']??'',20,900);
                $_SESSION['portal_user']=$this->s->portalByEmail($v['email']??'');$_SESSION['portal_until']=time()+1800;
                session_regenerate_id(true);$_SESSION['flash']=['success','E-mail reconhecido. Copie sua licença ou restaure a ativação abaixo.'];
            }
            elseif($op==='redeem'){ $_SESSION['portal_user']=$this->s->redeem($v['token']??''); $_SESSION['portal_until']=time()+1800; session_regenerate_id(true); }
            elseif($op==='reset'){
                if(!isset($_SESSION['portal_user'])) throw new Problem('Acesse novamente pelo link enviado.',403);
                $this->s->selfReset((int)$_SESSION['portal_user'],(int)($v['license_id']??0),(int)($v['device_id']??0)); $_SESSION['flash']=['success','Computador desvinculado. Você já pode ativar outro dispositivo.'];
            }
            elseif($op==='portal_logout') unset($_SESSION['portal_user']);
            else throw new Problem('Ação inválida.');
            $this->go('/ativar');
        }
        if($this->path!=='/acao') throw new Problem('Rota inválida.',404);
        $admin=$this->admin(); $actor=$admin['email']; $id=(int)($v['id']??0);
        switch($op){
            case 'logout': $_SESSION=[]; session_destroy(); $this->go('/entrar');
            case 'plan_save': $this->s->savePlan($v,$actor); break;
            case 'plan_delete':
                if((int)$db->value('SELECT COUNT(*) FROM licenses WHERE plan_id=?',[$id])>0 || (int)$db->value('SELECT COUNT(*) FROM orders WHERE plan_id=?',[$id])>0) $db->run('UPDATE plans SET active=0 WHERE id=?',[$id]);
                else { $db->run('DELETE FROM product_maps WHERE plan_id=?',[$id]); $db->run('DELETE FROM plans WHERE id=?',[$id]); }
                $this->s->audit($actor,'plan.deleted',(string)$id,'Planos em uso são arquivados.'); break;
            case 'user_save':
                $user=$this->s->saveUser($v,$actor); $_SESSION['flash']=['success','Usuário salvo. As licenças e os códigos de ativação estão abaixo.']; $this->go('/admin?view=users&id='.$user);
            case 'user_license_pcs':
                $this->s->setUserLicensePcs($id,(int)($v['license_id']??0),$v['max_pcs']??null,$actor,(string)($v['expires_at']??'')); $_SESSION['flash']=['success','Limite de computadores atualizado. Validade salva.']; $this->go('/admin?view=users&id='.$id);
            case 'user_delete': $this->s->deleteUser($id,$actor); break;
            case 'user_status':
                $status=$v['status']??'';if(!in_array($status,['active','blocked'],true))throw new Problem('Status inválido.');
                $db->run('UPDATE users SET status=? WHERE id=?',[$status,$id]);$this->s->audit($actor,'user.status',(string)$id,$status);break;
            case 'license_create': $license=$db->tx(fn()=> $this->s->createLicense((int)$v['user_id'],(int)$v['plan_id'],$v,$actor)); $_SESSION['flash']=['success','Licença criada. Copie o código de ativação abaixo.']; $this->go('/admin?view=licenses&id='.$license);
            case 'license_save': $this->s->manageLicense($id,$v,$actor); break;
            case 'settings_save': $this->s->saveSettings($v,$actor); break;
            case 'reveal_setting':
                if(!in_array($v['name']??'',['webhook_secret','uaz_token','smtp_password'],true)) throw new Problem('Campo inválido.');
                $this->json(['value'=>$this->s->settings()[$v['name']]]);
            case 'send_test':
                $number=preg_replace('/\D/','',$v['number']??''); if(!preg_match('/^[1-9][0-9]{7,14}$/',$number)) throw new Problem('Informe o telefone com país e DDD.');
                $this->s->queue('whatsapp',$number,'Matura Zap: sua integração de mensagens está funcionando.','test:'.bin2hex(random_bytes(12))); $this->s->audit($actor,'message.test','integration','Mensagem de teste adicionada à fila.'); break;
            case 'event_retry':
                $e=$db->one("SELECT * FROM events WHERE id=? AND kind='woocommerce'",[$id]); if(!$e||!$e['payload_cipher'])throw new Problem('Evento indisponível.');
                $this->s->webhook($this->s->open($e['payload_cipher']),'','',true); $this->s->audit($actor,'event.reprocessed',(string)$id); break;
            case 'message_retry':
                $db->run("UPDATE outbox SET status='pending', attempts=0, next_attempt=?, locked_at=NULL WHERE id=? AND status IN ('failed','uncertain')",[time(),$id]); $this->s->audit($actor,'message.requeued',(string)$id); break;
            case 'user_send_access':
                $u=$db->one("SELECT * FROM users WHERE id=? AND status='active'",[$id]); if(!$u)throw new Problem('Usuário indisponível.'); $this->s->requestPortal($u['email']); $this->s->audit($actor,'portal.link_requested',(string)$id); break;
            case 'release_save': $this->s->saveRelease($v,$actor); break;
            case 'release_pause': $db->run('UPDATE releases SET active=0 WHERE id=?',[$id]); $this->s->audit($actor,'release.paused',(string)$id); break;
            case 'password_change':
                $a=$db->one('SELECT * FROM admins WHERE id=?',[$admin['id']]);
                if(!password_verify($v['current_password']??'',$a['password_hash'])) throw new Problem('Senha atual incorreta.',403);
                if(strlen($v['new_password']??'')<12) throw new Problem('Use pelo menos 12 caracteres na nova senha.');
                $db->run('UPDATE admins SET password_hash=? WHERE id=?',[password_hash($v['new_password'],PASSWORD_DEFAULT),$a['id']]); session_regenerate_id(true); $this->s->audit($actor,'admin.password_changed',(string)$a['id']); break;
            default: throw new Problem('Ação não reconhecida.');
        }
        $_SESSION['flash']=['success','Alterações salvas.']; $this->go('/admin?view='.$this->safeView($v['return_view']??'dashboard').(!empty($v['return_id'])?'&id='.(int)$v['return_id']:''));
    }
}
