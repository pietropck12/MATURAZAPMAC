<?php
declare(strict_types=1);

final class Problem extends RuntimeException {
    public function __construct(string $message, public int $status = 400, public string $kind = 'invalid_request') { parent::__construct($message); }
}

final class Store {
    public PDO $pdo;
    public bool $mysql;
    public function __construct(array $config) {
        $this->pdo = new PDO($config['dsn'], $config['db_user'] ?? null, $config['db_password'] ?? null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
        $this->mysql = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
        if ($this->mysql) { $this->pdo->exec("SET time_zone = '+00:00'"); $this->pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED'); }
        else { $this->pdo->exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=10000;'); }
    }
    public function run(string $sql, array $args = []): PDOStatement { $q=$this->pdo->prepare($sql); $q->execute($args); return $q; }
    public function one(string $sql, array $args = []): ?array { return $this->run($sql,$args)->fetch() ?: null; }
    public function all(string $sql, array $args = []): array { return $this->run($sql,$args)->fetchAll(); }
    public function value(string $sql, array $args = []): mixed { return $this->run($sql,$args)->fetchColumn(); }
    public function tx(callable $fn): mixed {
        $this->pdo->beginTransaction();
        try { $v=$fn(); $this->pdo->commit(); return $v; }
        catch (Throwable $e) { if ($this->pdo->inTransaction()) $this->pdo->rollBack(); throw $e; }
    }
    public function lock(string $sql, array $args = []): ?array { return $this->one($sql . ($this->mysql ? ' FOR UPDATE' : ''), $args); }
    public function insert(string $table, array $row): int {
        $keys=array_keys($row);
        $this->run('INSERT INTO '.$table.' ('.implode(',',$keys).') VALUES ('.implode(',',array_fill(0,count($keys),'?')).')',array_values($row));
        return (int)$this->pdo->lastInsertId();
    }
    public function migrate(): void {
        $id=$this->mysql?'BIGINT PRIMARY KEY AUTO_INCREMENT':'INTEGER PRIMARY KEY AUTOINCREMENT';
        $text=$this->mysql?'LONGTEXT':'TEXT';
        $tables=[
            "admins (id $id, email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, created_at BIGINT NOT NULL)",
            "settings (name VARCHAR(100) PRIMARY KEY, value $text NOT NULL)",
            "users (id $id, name VARCHAR(190) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE, phone VARCHAR(40) NOT NULL DEFAULT '', status VARCHAR(20) NOT NULL DEFAULT 'active', created_at BIGINT NOT NULL)",
            "plans (id $id, name VARCHAR(190) NOT NULL, price_cents BIGINT NOT NULL DEFAULT 0, duration_days INTEGER NOT NULL, max_pcs INTEGER NOT NULL, max_whatsapp INTEGER NOT NULL, quota_scope VARCHAR(20) NOT NULL DEFAULT 'license', offline_hours INTEGER NOT NULL DEFAULT 24, reset_limit INTEGER NOT NULL DEFAULT 1, reset_window_days INTEGER NOT NULL DEFAULT 30, active INTEGER NOT NULL DEFAULT 1, created_at BIGINT NOT NULL)",
            "product_maps (id $id, product_id BIGINT NOT NULL, variation_id BIGINT NOT NULL DEFAULT 0, plan_id BIGINT NOT NULL, UNIQUE(product_id,variation_id))",
            "licenses (id $id, user_id BIGINT NOT NULL, plan_id BIGINT NOT NULL, code_hash VARCHAR(64) NOT NULL UNIQUE, code_cipher $text NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'active', expires_at BIGINT NOT NULL, max_pcs INTEGER NOT NULL, max_whatsapp INTEGER NOT NULL, quota_scope VARCHAR(20) NOT NULL, offline_hours INTEGER NOT NULL, reset_limit INTEGER NOT NULL, reset_window_days INTEGER NOT NULL, revision INTEGER NOT NULL DEFAULT 1, test_group INTEGER NOT NULL DEFAULT 0, notes TEXT, created_at BIGINT NOT NULL)",
            "devices (id $id, license_id BIGINT NOT NULL, fingerprint VARCHAR(64) NOT NULL, name VARCHAR(190) NOT NULL, token_hash VARCHAR(64) NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1, first_seen BIGINT NOT NULL, last_seen BIGINT NOT NULL, client_version VARCHAR(40) NOT NULL DEFAULT '', UNIQUE(license_id,fingerprint))",
            "accounts (id $id, license_id BIGINT NOT NULL, device_id BIGINT NOT NULL, account_hash VARCHAR(64) NOT NULL, label VARCHAR(40) NOT NULL, created_at BIGINT NOT NULL, UNIQUE(license_id,device_id,account_hash))",
            "resets (id $id, license_id BIGINT NOT NULL, device_id BIGINT, actor VARCHAR(190) NOT NULL, created_at BIGINT NOT NULL)",
            "portal_tokens (id $id, user_id BIGINT NOT NULL, token_hash VARCHAR(64) NOT NULL UNIQUE, expires_at BIGINT NOT NULL, used_at BIGINT, created_at BIGINT NOT NULL)",
            "orders (id $id, woo_id BIGINT NOT NULL, line_id BIGINT NOT NULL, user_id BIGINT NOT NULL, license_id BIGINT, plan_id BIGINT NOT NULL, status VARCHAR(30) NOT NULL, applied INTEGER NOT NULL DEFAULT 0, renewal_days INTEGER NOT NULL DEFAULT 0, modified_at BIGINT NOT NULL DEFAULT 0, created_at BIGINT NOT NULL, UNIQUE(woo_id,line_id))",
            "events (id $id, event_key VARCHAR(190) NOT NULL UNIQUE, kind VARCHAR(50) NOT NULL, status VARCHAR(30) NOT NULL, detail TEXT NOT NULL, payload_cipher $text, created_at BIGINT NOT NULL, processed_at BIGINT)",
            "outbox (id $id, unique_key VARCHAR(190) NOT NULL UNIQUE, channel VARCHAR(20) NOT NULL, recipient_cipher $text NOT NULL, message_cipher $text NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, next_attempt BIGINT NOT NULL, locked_at BIGINT, last_error VARCHAR(255) NOT NULL DEFAULT '', created_at BIGINT NOT NULL, sent_at BIGINT)",
            "audit (id $id, actor VARCHAR(190) NOT NULL, action VARCHAR(80) NOT NULL, target VARCHAR(190) NOT NULL, detail TEXT NOT NULL, created_at BIGINT NOT NULL)",
            "rate_limits (bucket VARCHAR(190) PRIMARY KEY, hits INTEGER NOT NULL, expires_at BIGINT NOT NULL)",
            "releases (id $id, version VARCHAR(40) NOT NULL UNIQUE, url TEXT NOT NULL, sha256 VARCHAR(64) NOT NULL, signature TEXT NOT NULL, size_bytes BIGINT NOT NULL, notes TEXT NOT NULL, channel VARCHAR(20) NOT NULL DEFAULT 'test', active INTEGER NOT NULL DEFAULT 0, mandatory INTEGER NOT NULL DEFAULT 0, created_at BIGINT NOT NULL)"
        ];
        foreach($tables as $table) $this->pdo->exec('CREATE TABLE IF NOT EXISTS '.$table.($this->mysql?' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci':''));
        $hasPrice=$this->mysql
            ?(bool)$this->one("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='plans' AND COLUMN_NAME='price_cents'")
            :(bool)array_filter($this->all('PRAGMA table_info(plans)'),fn($column)=>$column['name']==='price_cents');
        if(!$hasPrice)$this->pdo->exec('ALTER TABLE plans ADD COLUMN price_cents BIGINT NOT NULL DEFAULT 0');
    }
}
