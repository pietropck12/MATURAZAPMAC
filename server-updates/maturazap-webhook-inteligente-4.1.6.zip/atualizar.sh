#!/usr/bin/env bash
set -Eeuo pipefail
umask 027

DOMAIN='maturazap.superzapmarketing.net'
PANEL='/www/wwwroot/maturazap.linksite.online/panel'
CONFIG='/opt/maturazap/private/config.php'
PHP='/www/server/php/84/bin/php'
SERVICE='maturazap-php.service'
PACKAGE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
FILES=('src/Store.php' 'src/Service.php' 'src/Views.php' 'src/AdminViews.php' 'src/Web.php')

for name in "${FILES[@]}"; do
  [[ -f "$PACKAGE/files/$name" && ! -L "$PACKAGE/files/$name" ]] || { echo "Arquivo ausente ou inválido: $name"; exit 1; }
done
(cd -- "$PACKAGE" && sha256sum --check SHA256SUMS)

if [[ ${1:-} == '--check-package' ]]; then
  echo 'Pacote do webhook inteligente conferido.'
  exit 0
fi

[[ $# -eq 0 && $EUID -eq 0 ]] || { echo 'Execute como root no terminal do aaPanel, sem argumentos.'; exit 1; }
[[ -x "$PHP" && -f "$CONFIG" && -d "$PANEL" ]] || { echo 'A instalação do Matura Zap não foi encontrada no caminho esperado.'; exit 1; }
[[ "$(realpath "$PANEL")" == "$PANEL" ]] || { echo 'O caminho do painel é inesperado. Nada foi alterado.'; exit 1; }

exec 9>/run/maturazap-install.lock
flock -n 9 || { echo 'Outra atualização do Matura Zap está em andamento.'; exit 1; }
systemctl is-active --quiet "$SERVICE" || { echo 'O serviço do Matura Zap precisa estar ativo.'; exit 1; }

MATURAZAP_CONFIG="$CONFIG" "$PHP" -r '
$config = require getenv("MATURAZAP_CONFIG");
if (rtrim((string)($config["base_url"] ?? ""), "/") !== "https://maturazap.superzapmarketing.net") {
    fwrite(STDERR, "O endereço principal do painel está diferente do esperado.\n"); exit(1);
}
'

for name in "${FILES[@]}"; do
  target="$PANEL/$name"
  [[ -f "$target" && ! -L "$target" ]] || { echo "Arquivo instalado não encontrado ou inválido: $name"; exit 1; }
  [[ "$(realpath "$(dirname "$target")")" == "$(dirname "$target")" ]] || { echo "Diretório inesperado: $name"; exit 1; }
  "$PHP" -l "$PACKAGE/files/$name"
done

BACKUP="$(mktemp -d /opt/maturazap/backups/webhook-inteligente-XXXXXXXX)"
chmod 0700 "$BACKUP"
for name in "${FILES[@]}"; do
  mkdir -p -- "$BACKUP/$(dirname "$name")"
  cp -a -- "$PANEL/$name" "$BACKUP/$name"
done

SUCCESS=0
rollback() {
  local exit_code=$?
  trap - EXIT
  if [[ $SUCCESS -eq 1 ]]; then exit "$exit_code"; fi
  set +e
  for name in "${FILES[@]}"; do [[ -f "$BACKUP/$name" ]] && cp -a -- "$BACKUP/$name" "$PANEL/$name"; done
  systemctl kill --kill-who=main --signal=USR2 "$SERVICE" >/dev/null 2>&1 || true
  echo "Atualização interrompida; arquivos anteriores restaurados. Backup: $BACKUP"
  exit "$exit_code"
}
trap rollback EXIT

for name in "${FILES[@]}"; do
  temporary="$PANEL/$name.maturazap-new"
  [[ ! -L "$temporary" ]] || exit 1
  install -m 0644 -o root -g root "$PACKAGE/files/$name" "$temporary"
  mv -fT -- "$temporary" "$PANEL/$name"
done

MATURAZAP_CONFIG="$CONFIG" "$PHP" -r '
require "/www/wwwroot/maturazap.linksite.online/panel/src/Store.php";
$config=require getenv("MATURAZAP_CONFIG");
$db=new Store($config);$db->migrate();
'

systemctl kill --kill-who=main --signal=USR2 "$SERVICE"

healthy=0
for attempt in 1 2 3 4 5; do
  sleep 1
  if curl --fail --silent --show-error --max-time 10 --proto '=https' --resolve "$DOMAIN:443:127.0.0.1" "https://$DOMAIN/health?downloads=$(date +%s)" > "$BACKUP/health.json"; then healthy=1; break; fi
done
[[ $healthy -eq 1 ]] || { echo 'O painel não respondeu após a atualização.'; exit 1; }

MATURAZAP_CONFIG="$CONFIG" "$PHP" -r '
require "/www/wwwroot/maturazap.linksite.online/panel/src/Store.php";
$config=require getenv("MATURAZAP_CONFIG");$db=new Store($config);
$column=$db->mysql?$db->one("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=\"plans\" AND COLUMN_NAME=\"price_cents\""):null;
if(!$column)exit(1);
'
grep -Fq 'product_map.auto' "$PANEL/src/Service.php"
grep -Fq '{link_download_mac}' "$PANEL/src/Service.php"
grep -Fq 'Valor do plano' "$PANEL/src/AdminViews.php"
grep -Fq 'MaturaZap-Mac-Instalador-universal.dmg' "$PANEL/src/Web.php"

SUCCESS=1
trap - EXIT
echo
echo 'Webhook inteligente, valor dos planos e download direto do Mac instalados com sucesso.'
echo "Painel: https://$DOMAIN/admin?view=integrations"
echo "Planos: https://$DOMAIN/admin?view=plans"
echo "Mac: https://$DOMAIN/download/mac"
echo "Backup: $BACKUP"